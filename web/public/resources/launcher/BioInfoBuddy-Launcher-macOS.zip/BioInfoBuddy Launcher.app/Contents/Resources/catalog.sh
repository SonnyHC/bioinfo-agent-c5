# Generated from catalog.json; do not edit.
load_action() {
  case "$1" in
    single-cell-macos)
      action_title='单细胞 R 环境'
      env_name=sc_r_mac
      conda_packages=(r-base=4.4.3 r-base64enc r-boot r-cli r-cpp11 r-gbrd r-glue r-jsonlite r-lattice r-lifecycle r-lme4 r-locfit r-mass r-matrix r-minqa r-nlme r-nloptr r-ragg r-rbibutils r-rcpp r-rcppeigen r-rdpack r-reformulas r-rlang r-stringi r-systemfonts r-textshaping r-xml2)
      r_program=''
      ;;
    spatial-macos)
      action_title='空间转录组 Python 环境'
      env_name=st
      conda_packages=(python=3.12 scanpy anndata pandas matplotlib seaborn numpy pooch scipy python-igraph leidenalg openpyxl scanorama squidpy)
      r_program=''
      ;;
    case-single-cell-macos)
      action_title='单细胞案例配套依赖'
      env_name=sc_r_mac
      conda_packages=(r-base=4.4.3 r-base64enc r-boot r-cli r-cpp11 r-gbrd r-glue r-jsonlite r-lattice r-lifecycle r-lme4 r-locfit r-mass r-matrix r-minqa r-nlme r-nloptr r-ragg r-rbibutils r-rcpp r-rcppeigen r-rdpack r-reformulas r-rlang r-stringi r-systemfonts r-textshaping r-xml2)
      r_program='packages <- c("Seurat","ggplot2","Matrix","patchwork","ggdendro","viridisLite"); managed_library <- Sys.getenv("R_LIBS_USER"); dir.create(managed_library, recursive=TRUE, showWarnings=FALSE); .libPaths(managed_library); missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly=TRUE)]; if(length(missing)) install.packages(missing, lib=managed_library, repos="https://cloud.r-project.org"); stopifnot(all(vapply(packages, requireNamespace, logical(1), quietly=TRUE)))'
      ;;
    case-spatial-macos)
      action_title='空间转录组案例配套依赖'
      env_name=bioinfobuddy-st
      conda_packages=(python=3.12 scanpy=1.12.1 anndata pandas matplotlib seaborn numpy pooch scipy python-igraph leidenalg h5py)
      r_program=''
      ;;
    *) return 2;;
  esac
}
