#!/bin/bash
script_dir="$(cd "$(dirname "$0")" && pwd)"
exec /bin/bash "$script_dir/../install.sh" case-spatial-macos
